import articleController from './controllers/article.controller';

export { articleController }