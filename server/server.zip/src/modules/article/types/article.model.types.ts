export interface ArticleAttributes {
	id?: string;
	title?: string;
	text?: string;
	type?: string;
	UserId?: string;
	createdAt?: Date;
	updatedAt?: Date;
  }