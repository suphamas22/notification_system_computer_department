export interface NotificationAttributes {
	id?: number;
	name?: string;
    datetime?: Date;
    status?: number;
	createdAt?: Date;
	updatedAt?: Date;
  }