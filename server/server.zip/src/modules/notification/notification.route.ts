import express from "express";
import notificationController from "./notification.contoller";

const router = express.Router();

router.post('/', notificationController.handleCreateNotification)

export default router