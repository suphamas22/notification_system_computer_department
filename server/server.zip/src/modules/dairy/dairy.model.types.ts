export interface DairyAttributes {
	id?: number;
	name?: string;
	content?: string;
	datetime?: Date;
	createdAt?: Date;
	updatedAt?: Date;
  }