import { DairyAttributes } from "./dairy.model.types";
import db from "../../models"

const DairyModel = db.Dairy;

export const createDairy = async (body: DairyAttributes): Promise<DairyAttributes> => {
    try {
        const response = await DairyModel.create(body);
        return response 
    } catch (error) {
        throw new Error()
    }
}

export default {
    createDairy
}