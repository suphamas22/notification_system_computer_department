import { isAllValuesUndefined } from "./is-all-undefined";
export {
	isAllValuesUndefined
}